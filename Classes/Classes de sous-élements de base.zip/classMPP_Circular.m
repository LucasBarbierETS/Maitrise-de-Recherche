classdef classMPP_Circular < classJCA_Rigid

%% ========================================================================
%  Modèle unifié de plaque microperforée circulaire
%
%  Références :
%   [1] Atalla, N. & Sgard, F. (2007) – J. Sound Vib. 303(1–2)
%   [2] Ingard, U. (1953) – JASA
%   [3] Okuzono et al. (2019) – Acoust. Sci. Technol. 40(3)
%   [4] Stinson & Champoux (1992) – JASA
%   [5] Laly, Z. (2017) – “Acoustical modeling of MPP at high SPL”
%   [6] Laly, Z. (2018) – Thèse de doctorat, Université de Sherbrooke
%
%  Description :
%   Classe unique intégrant les comportements :
%     • Linéaire (Atalla & Sgard)
%     • Non-linéaire forts niveaux (Laly)
%     • Écoulement rasant
%     • Itératif
%
%  Auteur : Lucas Barbier
%  Version unifiée
%% ========================================================================

    methods
        %% ======== Constructeur ========
        function obj = classMPP_Circular(config)
            
            try
                phi = config.RelativePorosity;
            catch
                error('Impossible de calculer la matrice de transfert du sous-élement');
            end

            pr  = config.PerforationsRadius;
            t   = config.Thickness;
            s   = config.Section;
            S   = config.PerforatedAreaSurface;

            % Correction de longueur
            if isfield(config, 'ThicknessCorrection')
                tc = config.ThicknessCorrection;
            else
                tc = 0.48 * sqrt(pi * pr^2) * (1 - 1.14 * sqrt(phi)); % Allard-Ingard
                config.ThicknessCorrection = tc;
            end

            % Coefficients géométriques de base
            rh = pr;  % rayon hydraulique
            sig = @(env, varargin) classMPP_Circular.compute_resistivity(env, config, varargin{:});
            tor = @(env, varargin) classMPP_Circular.compute_tortuosity(env, config, varargin{:});

            % Fusion configuration JCA rigide
            config = perso_transfer_fields(classJCA_Rigid.create_config(s, t, phi, tor, sig, rh, rh), config);

            % Appel du constructeur parent
            obj@classJCA_Rigid(config);
        end


        %% ======== Matrice de transfert ========
        function TM = transfer_matrix(obj, env, options)

            arguments
                obj
                env
                options.pt_in = 0
                options.u_in = 0
                options.IndexPosition = [];
            end
            
            u_in = options.u_in;
            s = obj.Configuration.Section;
            sig = obj.Configuration.AirFlowResistivity;
            obj.Configuration.AirFlowResistivity = ...
                @(env) obj.compute_resistivity(env, obj.Configuration, ...
                    "v_rms", abs(u_in/(s*sqrt(2))), "M", env.M, 'IndexPosition', options.IndexPosition);

            obj.Configuration.Tortuosity = ...
                @(env) obj.compute_tortuosity(env, obj.Configuration, ...
                    "v_rms", abs(u_in/(s*sqrt(2))), "M", env.M, 'IndexPosition', options.IndexPosition);
            
            TM = transfer_matrix@classJCA_Rigid(obj, env);
        end
    end

    methods (Static, Access = public) % Physique

        %% ----- Fonction auxiliaire f(env, phi) -----
        function f = f(env, phi)
            f = sqrt(1/4 + 2*sqrt(2) * env.pi_rms ...
                / (env.air.parameters.rho * env.air.parameters.c0^2) ...
                * (1 - phi^2) / phi^2);
        end

        %% ----- Résistivité de passage de l’air -----
        function sig = compute_resistivity(env, config, options)
            
            arguments
                env
                config
                options.v_rms = 0
                options.M = 0
                options.IndexPosition = []
            end

            phi = config.RelativePorosity;
            pr  = config.PerforationsRadius;
            t   = config.Thickness;

            beta = config.Beta;
            Cd = config.Cd;
            q = config.q;
 
            sig = 8 * env.air.parameters.eta / (phi * pr^2) ...
                + beta * env.air.parameters.rho * (1 - phi^2) ...
                / (pi * t * phi * Cd^2) * options.v_rms;

            if all(options.IndexPosition == 1) % si la plaque est en surface
                sig = sig + env.air.parameters.Z0 * (1 - phi^2) / (phi * t) * q * options.M;
            end
        end


        %% ----- Tortuosité non-linéaire -----
        function tor = compute_tortuosity(env, config, options)
            
            arguments
                env
                config
                options.v_rms = 0
                options.M = 0
                options.IndexPosition = []
            end

            phi = config.RelativePorosity;
            pr = config.PerforationsRadius;
            t = config.Thickness;

            psi = 4/3;
            a = [1.0 -1.4092 0.0 0.33818 0.0 0.06793 -0.02287 0.003015 -0.01614];
            sum_a = dot(a, sqrt(phi).^(0:length(a)-1));

            tor =  1 + 2 * psi ./ (t * (1 + options.v_rms / (phi * env.air.parameters.c0))) ...
                * 0.48 * sqrt(pi * pr^2) * sum_a;
            
            if all(options.IndexPosition == 1) % si la plaque est en surface
                tor = tor / (1 + 305 * options.M^3);
            end
        end
    end

    methods (Static, Access = public) % COMSOL
        function output_model = set_COMSOL_2D_Model(obj, input_model, elem_index, sblm_index, env)
            output_model = ModelMPP(obj.Configuration, input_model, elem_index, sblm_index, env);
        end
    end

    methods (Static, Access = public) %  Configurations

        function config = create_config(perforated_area_surface, thickness, perforations_radius, relative_porosity, options)
            
        
            arguments
                % ---- Arguments positionnels ----
                perforated_area_surface
                thickness
                perforations_radius 
                relative_porosity 
        
                % ---- Name-Value optionnels ----
                options.PerforatedAreaWidth = NaN
                options.PerforatedAreaDepth = NaN
                options.PerforatedAreaRadius = NaN
                options.Beta = 1.6
                options.Cd = 0.76
                options.q = 0.3
            end
        
            % ---- Construction de la structure de configuration ----
            config = struct();
            config.PerforatedAreaSurface = perforated_area_surface;
            config.Thickness = thickness;
            config.PerforationsRadius = perforations_radius;
            config.RelativePorosity = relative_porosity;
            config.Section = perforated_area_surface * relative_porosity;
            config.PerforatedAreaWidth = options.PerforatedAreaWidth;
            config.PerforatedAreaDepth = options.PerforatedAreaDepth;
            config.PerforatedAreaRadius = options.PerforatedAreaRadius;
            config.Beta = options.Beta;
            config.Cd   = options.Cd;
            config.q    = options.q;
        end  

        function config = create_explicit_rectangular_plate_config(thickness, perforations_radius, width, depth, width_holes_number, depth_holes_number, arguments)
            
            arguments
                % ----- Paramètres principaux -----
                thickness (1,1) double {mustBePositive}                   % épaisseur de la plaque [m]
                perforations_radius (1,1) double {mustBePositive}         % rayon des perforations [m]
                width (1,1) double {mustBePositive}                       % largeur de la plaque [m]
                depth (1,1) double {mustBePositive}                       % profondeur de la plaque [m]
                width_holes_number (1,1) double {mustBeInteger, mustBePositive}   % nb de trous selon la largeur
                depth_holes_number (1,1) double {mustBeInteger, mustBePositive}   % nb de trous selon la profondeur
        
                % ----- Paramètres optionnels du modèle HL -----
                arguments.Beta (1,1) double {mustBePositive} = 1.6        % coefficient HL (Laly)
                arguments.Cd   (1,1) double {mustBePositive} = 0.76       % coefficient de décharge
                arguments.q    (1,1) double {mustBeNonnegative} = 0.3     % paramètre d’écoulement rasant
            end
        
            % ----- Calculs géométriques -----
            config.Thickness = thickness;
            config.PerforationsRadius = perforations_radius;
            config.Width = width;
            config.Depth = depth;
            config.Surface = width * depth;
        
            config.WidthHolesNumber = width_holes_number;
            config.DepthHolesNumber = depth_holes_number;
        
            config.Section = width_holes_number * depth_holes_number * pi * perforations_radius^2;
            config.Porosity = config.Section / config.Surface;
        
            % ----- Paramètres optionnels HL -----
            config.Beta = arguments.Beta;
            config.Cd   = arguments.Cd;
            config.q    = arguments.q;
        end 
    end

    methods (Static, Access = public) % Validation
        function validate(handle_env)

            % close all 
            perso_figure('Validation Circular MPP');

            % Données de référence : [1], fig. 3, 4 p. 9, 10

            % panel 1
            phi = 0.025; % porosité de la plaque
            d = 1e-3; % épaisseur de la plaque
            r = 0.5e-3; % diamètre des perforations
            c = 30e-3; % côté arbitraire
            s = c^2; % Section 
            MPP = classMPP_Circular(classMPP_Circular.create_config(s, d, r, phi));
            
            % Paramètres de la configuration

            D1 = 60e-3;
            cavity = classcavity(classcavity.create_config(s, D1));

            % foam 1
            phip1 = 0.99;
            torp1 = 1.02;
            sigp1 = 10900;
            vlp1 = 100e-6;
            tlp1 = 130e-6;
            
            % % foam 2
            % phip2 = 0.98;
            % torp2 = 1.5;
            % sigp2 = 50000;
            % vlp2 = 34e-6;
            % tlp2 = 130e-6;
            D2 = 20e-3; % épaisseur de la cavité arrière

            Porous1 = classJCA_Rigid(classJCA_Rigid.create_config(s, D2, phip1, torp1, sigp1, vlp1, tlp1));
            
            % Création des éléments
            E1 = classelement(classelement.create_config({MPP, cavity}, 'closed', s)); % fig.3
            E2 = classelement(classelement.create_config({MPP, Porous1}, 'closed', s)); % fig.4

            % importation des données de références
            data1 = readmatrix('Atalla2007_fig3_black_square.txt');
            data2 = readmatrix('Atalla2007_fig4_red.txt');
            [x_data1, y_data1] = perso_interpole_et_lisse(data1(:, 1), data1(:, 2), 1000, 0.05);
            [x_data2, y_data2] = perso_interpole_et_lisse(data2(:, 1), data2(:, 2), 1000, 0.05);

            env = handle_env(100, 0);
            
            % Tube = ImpedanceTube2D(ImpedanceTube2D.create_config({E1}));
            % Tube = Tube.launch_tube_measurement(env);
            
            % affichage des résultats
            subplot(1, 2, 1)
            hold on
            subtitle("Atalla2007 - fig. 3 - p. 9")
            plot(env.w / (2*pi), E1.alpha(env), 'Color', 'b', 'LineWidth', 1, 'DisplayName', 'Modèle analytique');
            % Tube.plot_alpha(env, 'Modèle numérique');
            plot(x_data1, y_data1, 'Color', 'g','LineWidth', 1, 'LineStyle', '--', 'DisplayName', 'Données de références');
            perso_configure_alpha_figure(5000);

            subplot(1, 2, 2)
            hold on
            subtitle("Atalla2007 - fig. 4 - p. 10")
            plot(env.w / (2*pi), E2.alpha(env), 'Color', 'b', 'LineWidth', 1, 'DisplayName', 'modèle foam 1');
            % plot(env.w / (2*pi), E2_2.alpha(env), 'Color', 'r',
            % 'LineWidth', 1, 'DisplayName', 'modèle foam 2'); % la référence s'est trompée de mousse
            plot(x_data2, y_data2, 'Color', 'g','LineWidth', 1, 'LineStyle', '--','DisplayName', 'Données de références');
            perso_configure_alpha_figure(5000);

            %% Temporaire - Validation de la contribution de la cavité jaune dans le module ETS
            % 
            % perso_figure('Validation numérique 2D - contribution cavité jaune - module ETS')
            % 
            % % panel 1
            % phi = 0.0812; % porosité de la plaque
            % t = 1e-3; % épaisseur de la plaque
            % r = 9.9219e-4; % diamètre des perforations
            % w = 0.012; % Largeur
            % d = 0.03; % Profondeur
            % s = w*d; % Section 
            % MPP = classMPP_Circular(classMPP_Circular.create_config(s, t, r, phi, w, d));
            % 
            % % Paramètres de la configuration
            % 
            % D1 = 115e-3; % 1e-3 + 114e-3
            % cavity = classcavity(classcavity_rectangular.create_config(D1, w, d));
            % 
            % % Création des éléments
            % E1 = classelement(classelement.create_config({MPP, cavity}, 'closed', s)); % fig.3
            % 
            % Tube = ImpedanceTube2D(ImpedanceTube2D.create_config({E1}));
            % Tube = Tube.launch_tube_measurement(env);
            % comsol_model = Tube.Configuration.ComsolModel;
            % folder_full_name = [env.Root, '\COMSOL\Optimisation\Optimisation REAR\Optimisations finales\optimisation_ETS_Poly_H1-4_08_25_06_14'];
            % mphsave(comsol_model, [folder_full_name, '\Validation numérique\Validation de la contribution de la cavité jaune de la cartouche ETS dans classMPP_Circular.mph']);
            % 
            % % affichage des résultats
            % hold on
            % subtitle("Atalla2007 - fig. 3 - p. 9")
            % plot(env.w / (2*pi), E1.alpha(env), 'Color', 'b', 'LineWidth', 1, 'DisplayName', 'Modèle analytique - classMPP_Circular');
            % Tube.plot_alpha(env, 'Modèle numérique - classMPP_Circular');

            %% Validation classMPP_Circular - TL avec écoulement

            % perso_figure('Validation classMPP_Circular - TL sans écoulement')
            % % Figures de réference 
            % % perso_ouvrir_lien_Zotero('zotero://open-pdf/library/items/CMZQ7B9B?page=257&annotation=DN9BHR8G')
            % 
            % Lx = 50.8e-3;
            % Lz = 254e-3;
            % w = Lz; % longueur de la zone traité
            % d = Lx; % tube carré
            % r = 0.6e-3;
            % t = 1.3e-3;
            % phi = 0.078;
            % D = 17.2e-3;
            % 
            % % création de l'environnement
            % env = create_environnement(23, 100800, 22, 1, 3000, 200, 100);
            % 
            % % création de l'objet de classe
            % E = classelement(classelement.create_config(...
            %     {classMPP_Circular(classMPP_Circular.create_config(w * d, t, r, phi, w, d)), ...
            %     classcavity(classcavity.create_config(D, w, d))}, 'closed', w * d));
            % 
            % TM_sb = E.side_branch_transfer_matrix(env, Lx, 0);
            % 
            % perso_plot_transfer_matrix(TM_sb, env, 'test', 3000);
        end
    
        function validate_HL(handle_env)

            close();
            
            %% Thèse Laly - Models Comparison

            perso_figure('Validation classMPP_Circular_HL - Thèse Laly - Models Comparison');

            subplot(2, 2, 1)
            title('Fig 3.3 - SPL = 110 dB')
            hold on 

            data3_3 = load('Thèse_Laly_fig3.3_red.txt');

            SPL = 110; 
            M = 0;
            env = handle_env(SPL, M);

            t = 1e-3;
            r = 0.25e-3/2;
            phi = 0.028;
            D = 30e-3;
            S = 1; % Surface arbitraire

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire');
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif');
            plot(data3_3(:, 1), data3_3(:, 2), 'DisplayName', 'Résultat expérimental de référence');
            perso_configure_alpha_figure(4000);

            %%%

            subplot(2, 2, 2)
            title('Fig 3.4 - SPL = 135 dB')
            hold on 

            data3_4 = load('Thèse_Laly_fig3.4_black.txt');

            SPL = 135; % Pression incidente
            M = 0;
            env = handle_env(SPL, M);

            t = 1.2e-3;
            r = 1e-3/2;
            phi = 0.0417;
            D = 40e-3;

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env), 'DisplayName', 'Prédiction du modèle linéaire');
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Prédiction du modèle fort niveau');
            plot(data3_4(:, 1), data3_4(:, 2), 'DisplayName', 'Résultat expérimental de référence');
            perso_configure_alpha_figure(4000);

            %%%

            subplot(2, 2, 3)
            title('Fig 3.5 - SPL = 143 dB')
            hold on 

            data3_5 = load('Thèse_Laly_fig3.5_black.txt');

            SPL = 143; % Pression incidente
            M = 0;
            env = handle_env(SPL, M);

            t = 0.8e-3;
            r = 1.2e-3/2;
            phi = 0.0523;
            D = 28e-3;

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env), 'DisplayName', 'Prédiction du modèle linéaire');
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Prédiction du modèle fort niveau');
            plot(data3_5(:, 1), data3_5(:, 2), 'DisplayName', 'Résultat expérimental de référence');
            perso_configure_alpha_figure(4000);

            %%%

            subplot(2, 2, 4)
            title('Fig 3.6 - SPL = 150 dB')
            hold on 

            data3_6 = load('Thèse_Laly_fig3.6_magenta.txt');

            SPL = 150; % Pression incidente
            M = 0;
            env = handle_env(SPL, M);

            t = 1.2e-3;
            r = 1.2e-3/2;
            phi = 0.072;
            D = 43e-3;

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env), 'DisplayName', 'Prédiction du modèle linéaire');
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Prédiction du modèle fort niveau');
            plot(data3_6(:, 1), data3_6(:, 2), 'DisplayName', 'Données de référence');
            perso_configure_alpha_figure(4000);

            
            %% Thèse Laly - Validation with litterature data
            
            perso_figure('Validation classMPP_Circular_HL - Thèse Laly - Validation with litterature data');

            title('Fig 3.8 - SPL = 143 dB')
            hold on 

            data3_8 = load('Thèse_Laly_fig3.8_grey.txt');

            SPL = 143; 
            M = 0;
            env = handle_env(SPL, M);

            t = 1e-3;
            r = 1e-3/2;
            phi = 0.0514;
            D = 100e-3;
            S = 1; % Surface arbitraire

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env), 'DisplayName', 'Prédiction du modèle linéaire');
            plot(env.w/(2*pi), E.alpha(env, 'iter Laly'), 'DisplayName', 'Prédiction du modèle fort niveau');
            plot(data3_8(:, 1), data3_8(:, 2), 'DisplayName', 'Résultat expérimental de référence');
            perso_configure_alpha_figure(4000);
            xlim([200 1400])
            ylim([0 1])
            
            % %% Thèse Laly - Validation on own measurements
            % 
            % perso_figure('Validation classMPP_Circular_HL - Thèse Laly - Validation on own measurements');
            % 
            % subplot(2, 2, 1)
            % title('Fig 3.11 - MPP#1 - SPL = 125, 150 dB')
            % hold on 
            % 
            % data3_11_125 = load('Thèse_Laly_fig3.11_grey125.txt');
            % data3_11_150 = load('Thèse_Laly_fig3.11_grey150.txt');
            % 
            % SPL1 = 125; 
            % SPL2 = 150;
            % M = 0;
            % env1 = handle_env(SPL1, M);
            % env2 = handle_env(SPL2, M);
            % 
            % t = 0.86e-3;
            % r = 1.517e-3/2;
            % phi = 0.0523;
            % D = 25e-3;
            % % S = 29e-3^2; % Surface arbitraire
            % S = 1;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi)); 
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % plot(env1.w/(2*pi), E_HL.alpha(env1), 'DisplayName', 'Modèle non-linéaire  - 125 dB');
            % plot(env1.w/(2*pi), E_HL.alpha(env1, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif - 125 dB');
            % plot(data3_11_125(:, 1), data3_11_125(:, 2), 'DisplayName', 'Données de référence - 125 dB');
            % plot(env2.w/(2*pi), E_HL.alpha(env2), 'DisplayName', 'Modèle non-linéaire - 150 dB');
            % plot(env2.w/(2*pi), E_HL.alpha(env2, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif - 150 dB');
            % plot(data3_11_150(:, 1), data3_11_150(:, 2), 'DisplayName', 'Données de référence - 150 dB ');
            % perso_configure_alpha_figure(4000);
            % 
            % %%%
            % 
            % subplot(2, 2, 2)
            % title('Fig 3.12 - MPP#2, SPL = 140 dB')
            % hold on 
            % 
            % data3_12 = load('Thèse_Laly_fig3.12_grey.txt');
            % 
            % SPL = 140;
            % M = 0;
            % env = handle_env(SPL, M);
            % 
            % t = 1.2e-3;
            % r = 1.38e-3/2;
            % phi = 0.049;
            % D = 30e-3;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi)); 
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire');
            % plot(env.w/(2*pi), E_HL.alpha(env, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif');
            % plot(data3_12(:, 1), data3_12(:, 2), 'DisplayName', 'Données de référence');
            % perso_configure_alpha_figure(4000);
            % 
            % %%%
            % 
            % subplot(2, 2, 3)
            % title('Fig 3.13 - MPP#2, SPL = 150 dB')
            % hold on 
            % 
            % data3_13 = load('Thèse_Laly_fig3.13_grey.txt');
            % 
            % SPL = 150; % Pression incidente
            % M = 0;
            % env = handle_env(SPL, M);
            % 
            % t = 1e-3;
            % r = 1.38e-3/2;
            % phi = 0.049;
            % D = 30e-3;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi)); 
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire');
            % plot(env.w/(2*pi), E_HL.alpha(env, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif');
            % plot(data3_13(:, 1), data3_13(:, 2), 'DisplayName', 'Données de référence');
            % perso_configure_alpha_figure(4000);
            % 
            % %%%
            % 
            % subplot(2, 2, 4)
            % title('Fig 3.14 - MPP#3, SPL = 150 dB')
            % hold on 
            % 
            % data3_14 = load('Thèse_Laly_fig3.14_grey.txt');
            % 
            % SPL = 150; % Pression incidente
            % M = 0;
            % env = handle_env(SPL, M);
            % 
            % t = 1e-3;
            % r = 1.43e-3/2;
            % phi = 0.0754;
            % D = 17.5e-3;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi)); 
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire');
            % plot(env.w/(2*pi), E_HL.alpha(env, 'iter'), 'DisplayName', 'Modèle non-linéaire itératif');
            % plot(data3_14(:, 1), data3_14(:, 2), 'DisplayName', 'Données de référence');
            % perso_configure_alpha_figure(4000);
         end
    
        function validate_flow(handle_env)

            %% Validation avec écoulement (Thèse Laly)

            perso_figure('Validation avec écoulement (Thèse Laly)');

            subplot(1, 2, 1)
            % title('Fig 5.1, M = 0.1 (V = 34 m/s)')
            title('MPP + cavité 3, SPL = 110 dB, M = 0.1 (V = 34 m/s)')
            hold on 

            data5_1 = load('Thèse_Laly_fig5.1_black.txt');

            SPL = 110;
            M = 0.1;
            env = handle_env(SPL, M);
    
            t = 1e-3;
            r = 0.3e-3;
            phi = 0.038;
            D = 20e-3;
            S = 1; % Surface arbitraire
            beta = 1.2; % Pas un gros impact

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi, 'Beta', beta)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Prédiction du code HL avec écoulement');
            plot(data5_1(:, 1), data5_1(:, 2), 'DisplayName', 'Prédiction du modèle de référence');
            perso_configure_alpha_figure(5000);
   
            %%%

            subplot(1, 2, 2)
            % title('Fig 5.2, M = 0.15')
            title('MPP + cavité 4, SPL = 120 dB, M = 0.15 (V = 51 m/s)')
            hold on 

            data5_2 = load('Thèse_Laly_fig5.2_black.txt');

            SPL = 120; % Pression incidente
            M = 0.15;
            env = handle_env(SPL, M);
    
            t = 1e-3;
            r = 0.5e-3;
            phi = 0.047;
            D = 40e-3;

            plate = classMPP_Circular_HL(classMPP_Circular.create_config(S, t, r, phi, 'Beta', beta)); 
            cavity = classcavity(classcavity.create_config(S, D));
            E = classelement(classelement.create_config({plate, cavity}, 'closed', S));
            plot(env.w/(2*pi), E.alpha(env, 'iter'), 'DisplayName', 'Prédiction du code HL avec écoulement');
            plot(data5_2(:, 1), data5_2(:, 2), 'DisplayName', 'Prédiction du modèle de référence');
            perso_configure_alpha_figure(4000);
    
            %%%

            % subplot(2, 2, 3)
            % title('Fig 5.4, M = 0.3')
            % hold on 
            % 
            % data5_4 = load('Thèse_Laly_fig5.4_black.txt');
            % 
            % SPL = 140; % % Pression incidente
            % M = 0.3;
            % env = handle_env(SPL, M);
            % 
            % t = 0.8e-3;
            % r = 0.6e-3;
            % phi = 0.06;
            % D = 30e-3;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi, [], [], beta)); 
            % plate_HL_flow = classMPP_Circular_HL_flow(classMPP_Circular_HL_flow.create_config(S, t, r, phi, [], [], beta));
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % E_HL_flow = classelement(classelement.create_config({plate_HL_flow, cavity}, 'closed', S));
            % 
            % % Modèle non linéaire itératif
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire sans écoulement');
            % plot(env.w/(2*pi), E_HL_flow.alpha(env), 'DisplayName', 'Modèle non-linéaire avec écoulement');
            % plot(data5_4(:, 1), data5_4(:, 2), 'DisplayName', 'Données de référence');
            % perso_configure_alpha_figure(5000);
            % 
            % %%%
            % 
            % subplot(2, 2, 4)
            % title('Fig 5.5, M = 0.2')
            % hold on 
            % 
            % data5_5 = load('Thèse_Laly_fig5.5_black.txt');
            % 
            % SPL = 145; % % Pression incidente
            % M = 0.2;
            % env = handle_env(SPL, M);
            % 
            % 
            % t = 1.5e-3;
            % r = 0.75e-3;
            % phi = 0.056;
            % D = 28e-3;
            % 
            % plate_HL = classMPP_Circular_HL(classMPP_Circular_HL.create_config(S, t, r, phi, [], [], beta)); 
            % plate_HL_flow = classMPP_Circular_HL_flow(classMPP_Circular_HL_flow.create_config(S, t, r, phi, [], [], beta));
            % cavity = classcavity(classcavity.create_config(S, D));
            % E_HL = classelement(classelement.create_config({plate_HL, cavity}, 'closed', S));
            % E_HL_flow = classelement(classelement.create_config({plate_HL_flow, cavity}, 'closed', S));
            % 
            % % Modèle non linéaire itératif
            % plot(env.w/(2*pi), E_HL.alpha(env), 'DisplayName', 'Modèle non-linéaire sans écoulement');
            % plot(env.w/(2*pi), E_HL_flow.alpha(env), 'DisplayName', 'Modèle non-linéaire avec écoulement');
            % plot(data5_5(:, 1), data5_5(:, 2), 'DisplayName', 'Données de référence');
            % perso_configure_alpha_figure(5000);

        end
    end
end